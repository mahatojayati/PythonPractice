#import pandas as pd

'''# Sample data (like a student report card)
data = {
    "Name": ["Alice", "Bob", "Charlie", "David", "Eva"],
    "Score": [85, 92, 78, 90, 96],
    "Passed": [True, True, False, True, True]
}
df = pd.DataFrame(data)

# 1️⃣ Select the "Score" column (like copying one column in Excel)
print(df["Score"])

# 2️⃣ Select Name + Passed columns (multiple columns)
print(df[["Name", "Passed"]])

# 3️⃣ Get the first two rows by position
print(df.iloc[0:2])

# 4️⃣ Get rows where score is more than 90 (smart filter)
high_scores = df[df["Score"] > 90]
print(high_scores)

# 5️⃣ Combine conditions (score > 85 AND passed)
combo = df[(df["Score"] > 85) & (df["Passed"] == True)]
print(combo)'''

#assignment
'''
Create a DataFrame with 6 friends and their:

Name, Hours_Slept, Mood (Good/Bad)

Write code to:

a) Select only Name and Mood

b) Show friends who slept less than 6 hours

c) Show friends with "Good" mood and 7+ hours sleep

'''
import pandas as pd

# Create the DataFrame
data = {
    'Name': ['Asha', 'Ben', 'Chloe', 'Dev', 'Ella', 'Farhan'],
    'Hours_Slept': [8, 5, 6, 4, 7, 9],
    'Mood': ['Good', 'Bad', 'Bad', 'Bad', 'Good', 'Good']
}

df = pd.DataFrame(data)

# a) Select only Name and Mood
print("a) Name and Mood:")
print(df[['Name', 'Mood']])

# b) Show friends who slept less than 6 hours
print("\nb) Slept less than 6 hours:")
print(df[df['Hours_Slept'] < 6])

# c) Show friends with 'Good' mood and 7+ hours sleep
print("\nc) Good mood and slept 7+ hours:")
print(df[(df['Mood'] == 'Good') & (df['Hours_Slept'] >= 7)])
