import pandas as pd

# Let's say this is your workout log
df = pd.DataFrame({
    "Exercise": ["Running", "Pushups", "Yoga", "Cycling"],
    "Minutes": [30, 15, 45, 60]
})

# 1️⃣ Add a new column: Calories burned (estimate: 5 cal/min)
df["Calories"] = df["Minutes"] * 5
print(df)

# 2️⃣ Edit value: Update Yoga to 50 mins
df.at[2, "Minutes"] = 50
print(df)

# 3️⃣ Drop the "Pushups" row (index 1)
df = df.drop(1)
print(df)

# 4️⃣ Rename column "Minutes" → "Duration"
df = df.rename(columns={"Minutes": "Duration"})
print(df)

# 5️⃣ Drop a column: Remove "Calories"
df = df.drop("Calories", axis=1)
print(df)

#assignment
'''Create a DataFrame of 4 food items with:

Item, Calories, Healthy (True/False)

Then:

Add a new column Double_Calories

Change the calories of one item

Drop the "Healthy" column

Rename "Item" to "Food"'''
import pandas as pd

# Step 1: Create the DataFrame
data = {
    'Item': ['Burger', 'Salad', 'Fries', 'Apple'],
    'Calories': [500, 150, 300, 95],
    'Healthy': [False, True, False, True]
}

df = pd.DataFrame(data)

# Step 2: Add a new column Double_Calories
df['Double_Calories'] = df['Calories'] * 2

# Step 3: Change the calories of one item (let's update 'Fries' to 280)
df.loc[df['Item'] == 'Fries', 'Calories'] = 280

# Step 4: Drop the "Healthy" column
df = df.drop('Healthy', axis=1)

# Step 5: Rename "Item" to "Food"
df = df.rename(columns={'Item': 'Food'})

# Final DataFrame
print(df)
