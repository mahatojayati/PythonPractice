import pandas as pd

# Employee basic info
'''df1 = pd.DataFrame({
    "Emp_ID": [1, 2, 3],
    "Name": ["Alice", "Bob", "Charlie"]
})

# Salary info from another source
df2 = pd.DataFrame({
    "Emp_ID": [2, 3, 4],
    "Salary": [50000, 60000, 55000]
})
inner = pd.merge(df1,df2, on="Emp_ID",how="inner")
right = pd.merge(df1,df2,on="Emp_ID",how="right")
left = pd.merge(df1,df2,on="Emp_ID",how="left")
outer = pd.merge(df1,df2,on="Emp_ID",how="outer")
print(inner)
print(outer)
print(left)
print(right)'''

#assignment
'''Create two DataFrames:

students_df: Student_ID, Name, Course

grades_df: Student_ID, Grade

Merge them using:

a) inner join

b) left join

c) outer join
(Observe how missing data is handled.)'''

import pandas as pd

# students_df
students_df = pd.DataFrame({
    'Student_ID': [111, 222, 333],
    'Name': ['Alice', 'Ellie', 'Jane'],
    'Course': ['BTech', 'BCom', 'BBA']
})

# grades_df
grades_df = pd.DataFrame({
    'Student_ID': [111, 222, 444],
    'Grade': ['A', 'B+', 'A-']
})
inner_merged = pd.merge(students_df, grades_df, on='Student_ID', how='inner')
print("a) Inner Join:\n", inner_merged)

left_merged = pd.merge(students_df, grades_df, on='Student_ID', how='left')
print("\nb) Left Join:\n", left_merged)

outer_merged = pd.merge(students_df, grades_df, on='Student_ID', how='outer')
print("\nc) Outer Join:\n", outer_merged)
