import pandas as pd 
grades = pd.Series([77,87,66], index=["Alice","Mick","Bob"])
print(grades)

data = {
    "Name": ["Alice", "Bob", "Charlie"],
    "Age": [25, 30, 35],
    "Score": [85, 90, 88]
}
df = pd.DataFrame(data)
print(df)

#assignment
'''Create your own Series showing the scores you got in 3 subjects. Then make a DataFrame showing 3 friends' names, their hobbies, and favorite colors.
'''

Marks = pd.Series([77,88,99], index=["Physics","Chemistry","Biology"])
print(Marks)

Friends = {
    "Name": ["Alia","Krish","Ananya"],
    "Hobbies": ["Hockey","Guitar","Cooking"],
    "Fav_Colour": ["Blue","Black","Green"] 
        }
df = pd.DataFrame(Friends)
print(df)
