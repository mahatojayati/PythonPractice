import pandas as pd

df = pd.DataFrame({
    "Name": ["Alice", "Bob", "Charlie", "David", "Eva"],
    "Score": [88, 95, 70, 95, 82],
    "Age": [20, 22, 21, 23, 20]
})
#sorted vales
print(df.sort_values("Score"))
#descending
print(df.sort_values("Score", ascending=False))
print(df.sort_values("Score", ascending=True))
print(df.sort_values(["Score","Age"]))
print(df.sort_values(["Score","Age"],ascending=False))
print(df.sort_values(["Score","Age"],ascending=True))
print(df.sort_values(["Age","Score"],ascending=True))
print(df.sort_values(["Age","Score"],ascending=False))
df["Rank"] = df["Score"].rank(ascending=False)
print(df.sort_values("Rank"))
df["Rank"] = df["Score"].rank(ascending=True)
print(df.sort_values("Rank"))
#reverse
print(df.sort_index(ascending=False))

#assignment
'''Create a DataFrame with 5 products:

Product, Price, Rating, Sales

Do the following:

a) Sort by Price (low to high)

b) Sort by Sales descending, then Rating descending

c) Add a column Sales_Rank where the highest sales = Rank 1'''



# Create product data
data = {
    'Product': ['Laptop', 'Phone', 'Tablet', 'Monitor', 'Headphones'],
    'Price': [70000, 40000, 30000, 15000, 5000],
    'Rating': [4.5, 4.7, 4.2, 4.3, 4.0],
    'Sales': [1500, 3000, 1000, 800, 2500]
}

df = pd.DataFrame(data)
print("Original DataFrame:\n", df)

price_sorted = df.sort_values(by='Price')
print("\nSorted by Price (low to high):\n", price_sorted)

sales_rating_sorted = df.sort_values(by=['Sales', 'Rating'], ascending=[False, False])
print("\nSorted by Sales (desc), then Rating (desc):\n", sales_rating_sorted)

df['Sales_Rank'] = df['Sales'].rank(ascending=False, method='min').astype(int)
print("\nDataFrame with Sales_Rank:\n", df)

