import pandas as pd

# Sample data: food orders at a café
df = pd.DataFrame({
    "Item": ["Burger", "Burger", "Fries", "Fries", "Salad", "Salad"],
    "Waiter": ["A", "B", "A", "A", "B", "B"],
    "Price": [120, 130, 60, 65, 90, 85]
})
#average price
print(df.groupby("Item")["Price"].mean())
#total price of the order
print(df.groupby("Item")["Price"].sum())
#no. of orders
print(df.groupby("Item")["Price"].count())
#total sales of waiters
print(df.groupby("Waiter")["Price"].sum())
#summary
summary = df.groupby("Item")["Price"].agg(["mean", "max", "count"])
print("Summary Stats per Item:\n", summary)


#assignment
'''Create a DataFrame with:

Employee, Department, Hours_Worked, Salary

Then:

a) Group by Department and get total Salary

b) Get average Hours_Worked per Department

c) Apply .agg() to get both min and max salary by department

'''

# Create the DataFrame
data = {
    'Employee': ['Alice', 'Bob', 'Charlie', 'Diana', 'Evan', 'Fay'],
    'Department': ['HR', 'IT', 'IT', 'Finance', 'HR', 'Finance'],
    'Hours_Worked': [40, 38, 45, 42, 36, 48],
    'Salary': [50000, 60000, 65000, 58000, 52000, 61000]
}

df = pd.DataFrame(data)

# a) Group by Department and get total Salary
total_salary = df.groupby('Department')['Salary'].sum()
print("a) Total Salary by Department:")
print(total_salary)

# b) Average Hours_Worked per Department
avg_hours = df.groupby('Department')['Hours_Worked'].mean()
print("\nb) Average Hours Worked by Department:")
print(avg_hours)

# c) Min and Max Salary by Department using .agg()
salary_stats = df.groupby('Department')['Salary'].agg(['min', 'max'])
print("\nc) Min and Max Salary by Department:")
print(salary_stats)
