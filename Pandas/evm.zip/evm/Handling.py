# Handling Missing Values
import pandas as pd
data = {
    "Name": ["Alice", "Bob", "Charlie", "David"],
    "Age": [25, None, 30, None],
    "City": ["Delhi", "Mumbai", None, "Bangalore"]
}
df = pd.DataFrame(data)
#Returns True if values are missing
print(df.isnull()) #or print(df.isna()) 
#shows how many values are missing
print(df.isnull().sum()) 
#Drop missing rows
print(df.dropna())
#fill missing values
print(df.fillna(value=10))

#assignment
'''
Create a DataFrame with 5 rows: Student, Marks, Grade
(Leave at least 2 cells empty.)

Then:

a) Count total missing values

b) Fill missing marks with the column's average

c) Fill missing grades with "Pending"

d) Drop rows with any missing values and print the result

'''
data= {
    'Student': ["Alice","Jean","Bob","Nick"],
    'Marks': [88,99,81,90],
    'Grade': ['A','O','A','A+'],
    'Class': [None,None,None,None],
    'ID': [None,None,None,None]
}
df = pd.DataFrame(data)
#missing values
print(df.isnull())
#total missing values
print(df.isnull().sum())
#filling missing values with "Pending"
print(df.fillna("Pending"))
#droping rows with missing values
print(df.dropna())
